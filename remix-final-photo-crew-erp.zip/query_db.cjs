const { createClient } = require('@supabase/supabase-js');
require('dotenv').config({ path: '.env' });
const supabase = createClient(process.env.VITE_SUPABASE_URL, process.env.VITE_SUPABASE_SERVICE_ROLE_KEY || process.env.VITE_SUPABASE_ANON_KEY);

async function check() {
  const { data, error } = await supabase.rpc('execute_sql', { sql: `
    SELECT * FROM pg_indexes WHERE indexname = 'idx_unique_staff_per_order';
  ` });
  console.log("Indexes:", data, error);
}
check();
